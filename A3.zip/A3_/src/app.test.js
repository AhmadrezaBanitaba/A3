import todo from './todos.json';

const num = todo.length;

describe('Number test', () => {
    test('Number of to dos = 4', () => {
        expect(num).toBe(4);
    });
});

// Strings
const stringTest = todo[1].name;

describe('String test', () => {
    test('There is a cat in the name', () => {
        expect(stringTest).toContain('cat');
    });
});


const list = ['Romeo', 'Echo', 'Zulu'];
describe('Array test', () => {
    test('The list mentiones ACIT 3625', () => {
        expect(['Romeo', 'Echo', 'Zulu', 'Alpha']).toEqual(expect.arrayContaining(list));
    });
});
